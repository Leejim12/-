from django.apps import AppConfig


class MySangpumConfig(AppConfig):
    name = 'my_sangpum'
